clc
clearvars

close all

% Specify the Excel file path
excelFilePath1 = 'beam/length.xlsx';
excelFilePath2 = 'beam/iterations.xlsx';
excelFilePath3 = 'beam/maxiter.xlsx';
excelFilePath4 = 'beam/steps.xlsx';

% Read the Excel file
try
    % Use xlsread to read the data
    dataMatrix1 = readmatrix(excelFilePath1);
    dataMatrix2= xlsread(excelFilePath2);
    dataMatrix3 = xlsread(excelFilePath3);
    dataMatrix4 = xlsread(excelFilePath4);



    %	CYL	GDC	GMRD-ALL	GMRD-E-D	GMRD-E-R	GMRD-N-ALL	GMRD-N-D	GMRD-N-R	MGDC	MNP	MRD	MUNP	NP	UNP
    index=[12 15 2 3 10 4 6 5 7 9 8];
    k=dataMatrix2(:,1);
    steplength=dataMatrix1(2:end,index);
    iterations=dataMatrix2(:,index);
    steps=dataMatrix4(:,index);

    markers = {'*', 'o', '.', 'x', '+', 's', 'd', '^', 'v', '>', '<', 'p'};
    names= {'MRD', 'UNP', 'CAL', 'GDC', 'MGDC', 'EMRD-A', 'EMRD-R', 'EMRD-T', 'NMRD-A', 'NMRD-R', 'NMRD-T'};

    for i=1:11
        figure(1);          plot(k, steplength(:, i), [markers{i} '-'], 'DisplayName', names{i}, 'MarkerSize', 4, 'MarkerFaceColor', 'auto'); hold on
    end
    xlabel('$$k$$', 'Interpreter', 'latex');
    ylabel('$$L^i$$', 'Interpreter', 'latex');
    legend('show');
    set(gca, 'FontName', 'Times New Roman');


    % Create inset plot
    ax2 = axes('Position',[.22 .5 .4 .4]); % [left bottom width height]
    box on;
for i=1:11
% Plot the magnified region
plot(ax2,k, steplength(:, i), [markers{i} '-'], 'DisplayName', names{i}, 'MarkerSize', 4, 'MarkerFaceColor', 'auto'); hold on
% plot(ax2, x, y, 'LineWidth', 2); hold on
end
xlabel(ax2, '$$k$$', 'Interpreter', 'latex');
ylabel(ax2, '$$L^i$$', 'Interpreter', 'latex');
title(ax2, 'Magnified Region');

    for i=1:11
        figure(2);          plot(k, iterations(:, i), [markers{i} '-'], 'DisplayName', names{i}, 'MarkerSize', 4, 'MarkerFaceColor', 'auto'); hold on
    end
    xlabel('$$k$$', 'Interpreter', 'latex');
    ylabel('#Iterations', 'Interpreter', 'latex');
    legend('show');
    set(gca, 'FontName', 'Times New Roman');

        % Create inset plot
    ax2 = axes('Position',[.5 .1 .3 .3]); % [left bottom width height]
    box on;
for i=1:11
% Plot the magnified region
plot(ax2,k, iterations(:, i), [markers{i} '-'], 'DisplayName', names{i}, 'MarkerSize', 4, 'MarkerFaceColor', 'auto'); hold on
% plot(ax2, x, y, 'LineWidth', 2); hold on
end
xlabel(ax2, '$$k$$', 'Interpreter', 'latex');
ylabel(ax2, '$$L^i$$', 'Interpreter', 'latex');
title(ax2, 'Magnified Region');


    for i=1:11
        figure(3);          plot(k, steps(:, i), [markers{i} '-'], 'DisplayName', names{i}, 'MarkerSize', 4, 'MarkerFaceColor', 'auto'); hold on
    end
    xlabel('$$k$$', 'Interpreter', 'latex');
    ylabel('#Steps', 'Interpreter', 'latex');
    legend('show');
    set(gca, 'FontName', 'Times New Roman');


    % Add labels, legend, and customize plot appearance


catch
    % Handle errors, if any
    disp('Error reading Excel file. Check the file path and format.');
end

